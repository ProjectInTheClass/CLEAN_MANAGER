//
//  ListCollectionViewCell.swift
//  CLEAN
//
//  Created by eunji on 2018. 6. 6..
//  Copyright © 2018년 clean. All rights reserved.
//

import UIKit

class ListCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var placeImageView: UIImageView!
    
}

